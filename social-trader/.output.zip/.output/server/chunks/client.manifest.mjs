const client_manifest = {
  "assets/svg/desktop-cover.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "desktop-cover.46691c00.svg",
    "src": "assets/svg/desktop-cover.svg"
  },
  "assets/svg/home-page-faq.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "home-page-faq.6686ccf3.svg",
    "src": "assets/svg/home-page-faq.svg"
  },
  "assets/logos/video.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "video.542bfd5d.png",
    "src": "assets/logos/video.png"
  },
  "assets/svg/fb-icon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "fb-icon.6a9d697c.svg",
    "src": "assets/svg/fb-icon.svg"
  },
  "assets/svg/tw-icon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "tw-icon.be623e29.svg",
    "src": "assets/svg/tw-icon.svg"
  },
  "assets/svg/inst-con.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "inst-con.79194e78.svg",
    "src": "assets/svg/inst-con.svg"
  },
  "assets/svg/ln-icon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "ln-icon.c26690f5.svg",
    "src": "assets/svg/ln-icon.svg"
  },
  "assets/svg/tl-icon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "tl-icon.76490d83.svg",
    "src": "assets/svg/tl-icon.svg"
  },
  "assets/svg/faq-arrow.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "faq-arrow.35678e0e.svg",
    "src": "assets/svg/faq-arrow.svg"
  },
  "assets/svg/ds-icon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "ds-icon.ac4ad561.svg",
    "src": "assets/svg/ds-icon.svg"
  },
  "assets/svg/mobile-cover.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "mobile-cover.9cdd41f9.svg",
    "src": "assets/svg/mobile-cover.svg"
  },
  "assets/svg/menu-mobile.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "menu-mobile.7ae199fd.svg",
    "src": "assets/svg/menu-mobile.svg"
  },
  "assets/svg/logout-mobile.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "logout-mobile.641f3982.svg",
    "src": "assets/svg/logout-mobile.svg"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.a45cc675.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "layouts/Default.vue",
      "layouts/empty.vue",
      "virtual:nuxt:C:/Users/Michelle/Documents/GitHub/2023/socialtrader-frontend/social-trader/.nuxt/error-component.mjs"
    ],
    "css": [
      "entry.ef3a6c12.css"
    ],
    "assets": [
      "desktop-cover.46691c00.svg"
    ]
  },
  "entry.ef3a6c12.css": {
    "file": "entry.ef3a6c12.css",
    "resourceType": "style"
  },
  "desktop-cover.46691c00.svg": {
    "file": "desktop-cover.46691c00.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "virtual:nuxt:C:/Users/Michelle/Documents/GitHub/2023/socialtrader-frontend/social-trader/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.099d3326.js",
    "src": "virtual:nuxt:C:/Users/Michelle/Documents/GitHub/2023/socialtrader-frontend/social-trader/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.e22a0b42.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": [
      "index.7d84fe6d.css"
    ],
    "assets": [
      "mobile-cover.9cdd41f9.svg",
      "video.542bfd5d.png",
      "faq-arrow.35678e0e.svg",
      "home-page-faq.6686ccf3.svg"
    ]
  },
  "index.7d84fe6d.css": {
    "file": "index.7d84fe6d.css",
    "resourceType": "style"
  },
  "mobile-cover.9cdd41f9.svg": {
    "file": "mobile-cover.9cdd41f9.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "video.542bfd5d.png": {
    "file": "video.542bfd5d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "faq-arrow.35678e0e.svg": {
    "file": "faq-arrow.35678e0e.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "home-page-faq.6686ccf3.svg": {
    "file": "home-page-faq.6686ccf3.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.ff302ed8.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "login.dfb11ff2.css": {
    "file": "login.dfb11ff2.css",
    "resourceType": "style"
  },
  "layouts/Default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Default.bb4c6627.js",
    "src": "layouts/Default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": [
      "Default.a8b2119e.css"
    ],
    "assets": [
      "fb-icon.6a9d697c.svg",
      "tw-icon.be623e29.svg",
      "inst-con.79194e78.svg",
      "ln-icon.c26690f5.svg",
      "tl-icon.76490d83.svg",
      "ds-icon.ac4ad561.svg",
      "menu-mobile.7ae199fd.svg",
      "logout-mobile.641f3982.svg"
    ]
  },
  "Default.a8b2119e.css": {
    "file": "Default.a8b2119e.css",
    "resourceType": "style"
  },
  "fb-icon.6a9d697c.svg": {
    "file": "fb-icon.6a9d697c.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "tw-icon.be623e29.svg": {
    "file": "tw-icon.be623e29.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "inst-con.79194e78.svg": {
    "file": "inst-con.79194e78.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "ln-icon.c26690f5.svg": {
    "file": "ln-icon.c26690f5.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "tl-icon.76490d83.svg": {
    "file": "tl-icon.76490d83.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "ds-icon.ac4ad561.svg": {
    "file": "ds-icon.ac4ad561.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "menu-mobile.7ae199fd.svg": {
    "file": "menu-mobile.7ae199fd.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logout-mobile.641f3982.svg": {
    "file": "logout-mobile.641f3982.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "file": "empty.7830fb37.js",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.0be482f4.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_composables.7919fa7f.js"
    ],
    "css": []
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "_composables.7919fa7f.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.7919fa7f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.e2cb53a3.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_composables.7919fa7f.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "pages/login.css": {
    "resourceType": "style",
    "file": "login.dfb11ff2.css",
    "src": "pages/login.css"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.7d84fe6d.css",
    "src": "pages/index.css"
  },
  "layouts/Default.css": {
    "resourceType": "style",
    "file": "Default.a8b2119e.css",
    "src": "layouts/Default.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.ef3a6c12.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
