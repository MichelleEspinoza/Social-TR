const Footer_vue_vue_type_style_index_0_scoped_2faa8a35_lang = "p[data-v-2faa8a35]{font-size:14px;font-style:normal;font-weight:500;line-height:20px}";

const FooterStyles_29cc5b90 = [Footer_vue_vue_type_style_index_0_scoped_2faa8a35_lang];

export { FooterStyles_29cc5b90 as default };
//# sourceMappingURL=Footer-styles.29cc5b90.mjs.map
