import { useSSRContext, mergeProps, defineComponent, ref, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const __default__$1 = {
  name: "LogoComponent"
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  __ssrInlineRender: true,
  props: {
    width: null,
    height: null
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-dark dark:text-white" }, _attrs))}><svg${ssrRenderAttr("width", __props.width || 0)}${ssrRenderAttr("height", __props.height || 0)} viewBox="0 0 96 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M41.2489 13.6172C43.5944 13.6172 44.6688 12.4642 44.6688 11.1147C44.6688 7.7737 39.0217 9.2935 39.0217 6.77793C39.0217 5.8608 39.7685 5.11401 41.4454 5.11401C42.2577 5.11401 43.1751 5.36291 43.9611 5.87389L44.2885 5.10088C43.555 4.58991 42.4805 4.28857 41.4454 4.28857C39.1134 4.28857 38.0653 5.45465 38.0653 6.80414C38.0653 10.1975 43.7121 8.65153 43.7121 11.1671C43.7121 12.0711 42.9654 12.7917 41.2489 12.7917C40.0437 12.7917 38.8776 12.3201 38.2225 11.6781L37.8425 12.4249C38.5238 13.1324 39.8733 13.6172 41.2489 13.6172Z" fill="currentColor"></path><path d="M50.7901 13.6172C53.5417 13.6172 55.5987 11.6388 55.5987 8.95286C55.5987 6.26695 53.5417 4.28857 50.7901 4.28857C48.0126 4.28857 45.9688 6.28008 45.9688 8.95286C45.9688 11.6256 48.0126 13.6172 50.7901 13.6172ZM50.7901 12.7524C48.5759 12.7524 46.9251 11.1409 46.9251 8.95286C46.9251 6.76484 48.5759 5.15331 50.7901 5.15331C52.9911 5.15331 54.6289 6.76484 54.6289 8.95286C54.6289 11.1409 52.9911 12.7524 50.7901 12.7524Z" fill="currentColor"></path><path d="M61.7545 13.6172C63.1043 13.6172 64.3096 13.1586 65.1219 12.2677L64.5061 11.6519C63.7595 12.4249 62.8421 12.7524 61.7939 12.7524C59.5798 12.7524 57.9158 11.1278 57.9158 8.95286C57.9158 6.77793 59.5798 5.15331 61.7939 5.15331C62.8421 5.15331 63.7595 5.48086 64.5061 6.24074L65.1219 5.62498C64.3096 4.73403 63.1043 4.28857 61.7677 4.28857C59.0034 4.28857 56.9595 6.26695 56.9595 8.95286C56.9595 11.6388 59.0034 13.6172 61.7545 13.6172Z" fill="currentColor"></path><path d="M67.189 13.5385H68.1584V4.36719H67.189V13.5385Z" fill="currentColor"></path><path d="M77.9946 13.5385H79.0166L74.8242 4.36719H73.8675L69.675 13.5385H70.6839L71.7846 11.0885H76.8943L77.9946 13.5385ZM72.1382 10.3024L74.3393 5.37605L76.5403 10.3024H72.1382Z" fill="currentColor"></path><path d="M80.5337 13.5385H86.6395V12.7H81.5035V4.36719H80.5337V13.5385Z" fill="currentColor"></path><path d="M40.2139 27.8974H42.3364V20.4556H45.2714V18.7261H37.2791V20.4556H40.2139V27.8974Z" fill="currentColor"></path><path d="M54.5366 27.8974L52.4795 24.9495C53.6718 24.4385 54.3659 23.4297 54.3659 22.054C54.3659 19.997 52.8332 18.7261 50.3831 18.7261H46.4131V27.8974H48.5358V25.3426H50.3831H50.4878L52.2568 27.8974H54.5366ZM52.2174 22.054C52.2174 23.0497 51.5622 23.6524 50.265 23.6524H48.5358V20.4556H50.265C51.5622 20.4556 52.2174 21.0451 52.2174 22.054Z" fill="currentColor"></path><path d="M62.9001 27.8974H65.1274L61.0265 18.7261H58.9301L54.8423 27.8974H57.0175L57.8298 25.9321H62.0878L62.9001 27.8974ZM58.5108 24.3206L59.9652 20.8093L61.4195 24.3206H58.5108Z" fill="currentColor"></path><path d="M66.0789 27.8974H70.2454C73.2456 27.8974 75.3027 26.0894 75.3027 23.3118C75.3027 20.5342 73.2456 18.7261 70.2454 18.7261H66.0789V27.8974ZM68.2015 26.1549V20.4686H70.1408C71.9619 20.4686 73.1541 21.5561 73.1541 23.3118C73.1541 25.0674 71.9619 26.1549 70.1408 26.1549H68.2015Z" fill="currentColor"></path><path d="M79.0129 26.1942V24.0717H83.2709V22.4208H79.0129V20.4293H83.8342V18.7261H76.9033V27.8974H84.0045V26.1942H79.0129Z" fill="currentColor"></path><path d="M93.8167 27.8974L91.7597 24.9495C92.9519 24.4385 93.6464 23.4297 93.6464 22.054C93.6464 19.997 92.1137 18.7261 89.6636 18.7261H85.6936V27.8974H87.8163V25.3426H89.6636H89.7683L91.5369 27.8974H93.8167ZM91.4979 22.054C91.4979 23.0497 90.8427 23.6524 89.5455 23.6524H87.8163V20.4556H89.5455C90.8427 20.4556 91.4979 21.0451 91.4979 22.054Z" fill="currentColor"></path><path d="M21.9956 29.6463L31.9859 2.62354L25.1074 4.58883L7.5835 14.9066L21.9956 29.6463Z" fill="url(#paint0_linear_807_3853)"></path><path d="M3.38869 13.738L21.9958 29.6463L15.9361 2.62354L3.80453 9.4637C2.21929 10.3575 2.00546 12.5554 3.38869 13.738Z" fill="url(#paint1_linear_807_3853)"></path><path d="M3.38869 13.7379L21.9958 29.6463L31.896 2.6665L4.15825 9.3781C3.92356 9.43487 3.69268 9.51738 3.50031 9.66331C2.1976 10.6516 2.0995 12.6357 3.38869 13.7379Z" fill="url(#paint2_linear_807_3853)"></path><path d="M31.9857 2.62354H15.9358L3.79989 9.46616C2.21587 10.3593 2.00087 12.5548 3.38155 13.7383L10.8588 20.1474C9.75754 19.2034 9.85965 17.4694 11.0642 16.6612L31.9857 2.62354Z" fill="url(#paint3_linear_807_3853)"></path><path d="M25.9261 2.62354H17.4099L4.54819 10.1043C2.98913 11.0111 2.79093 13.1852 4.16033 14.359L8.23849 17.8546C7.13695 16.9103 7.23865 15.1761 8.443 14.3671L25.9261 2.62354Z" fill="url(#paint4_linear_807_3853)"></path><path d="M20.194 2.62354H15.9358L3.79443 9.47322C2.20339 10.3708 1.99595 12.58 3.39209 13.7581L5.82721 15.8129C4.6046 14.7812 4.71628 12.8643 6.05043 11.9816L20.194 2.62354Z" fill="url(#paint5_linear_807_3853)"></path><defs><linearGradient id="paint0_linear_807_3853" x1="24.0459" y1="15.073" x2="-4.05664" y2="42.3551" gradientUnits="userSpaceOnUse"><stop offset="0.10651" stop-color="#00746B"></stop><stop offset="0.537132" stop-color="#6FECE3"></stop><stop offset="0.760384" stop-color="#8CF4C3"></stop><stop offset="0.977965" stop-color="#004F49"></stop></linearGradient><linearGradient id="paint1_linear_807_3853" x1="12.2814" y1="16.3038" x2="3.5432" y2="34.9916" gradientUnits="userSpaceOnUse"><stop offset="0.10651" stop-color="#0BA499"></stop><stop offset="0.537132" stop-color="#6FECE3"></stop><stop offset="0.760384" stop-color="#8CF4C3"></stop><stop offset="0.977965" stop-color="#028B82"></stop></linearGradient><linearGradient id="paint2_linear_807_3853" x1="13.6397" y1="11.5842" x2="23.4858" y2="27.2819" gradientUnits="userSpaceOnUse"><stop offset="0.109977" stop-color="#06433F"></stop><stop offset="0.296412" stop-color="#004F49" stop-opacity="0"></stop></linearGradient><linearGradient id="paint3_linear_807_3853" x1="28.6138" y1="0.302148" x2="7.92455" y2="21.6862" gradientUnits="userSpaceOnUse"><stop offset="0.10651" stop-color="#05915E"></stop><stop offset="0.364188" stop-color="#3CD077"></stop><stop offset="0.537132" stop-color="#6FECB0"></stop><stop offset="0.788628" stop-color="#60FFB4"></stop><stop offset="0.977965" stop-color="#004F49"></stop></linearGradient><linearGradient id="paint4_linear_807_3853" x1="19.3291" y1="2.07665" x2="5.49675" y2="17.749" gradientUnits="userSpaceOnUse"><stop offset="0.10651" stop-color="#0AA46C"></stop><stop offset="0.364188" stop-color="#40CE79"></stop><stop offset="0.537132" stop-color="#6FECB0"></stop><stop offset="0.760384" stop-color="#60FFB4"></stop><stop offset="0.977965" stop-color="#004F49"></stop></linearGradient><linearGradient id="paint5_linear_807_3853" x1="14.9078" y1="2.14995" x2="2.84958" y2="14.7916" gradientUnits="userSpaceOnUse"><stop offset="0.10651" stop-color="#017C50"></stop><stop offset="0.364188" stop-color="#3BBC6E"></stop><stop offset="0.537132" stop-color="#6FECB0"></stop><stop offset="0.744375" stop-color="#60FFB4"></stop><stop offset="0.977965" stop-color="#004F49"></stop></linearGradient></defs></svg></div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/Logo.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _imports_1 = "" + globalThis.__buildAssetsURL("fb-icon.6a9d697c.svg");
const _imports_2 = "" + globalThis.__buildAssetsURL("tw-icon.be623e29.svg");
const _imports_3$1 = "" + globalThis.__buildAssetsURL("inst-con.79194e78.svg");
const _imports_3 = "" + globalThis.__buildAssetsURL("ln-icon.c26690f5.svg");
const _imports_4$1 = "" + globalThis.__buildAssetsURL("tl-icon.76490d83.svg");
const _imports_5 = "" + globalThis.__buildAssetsURL("ds-icon.ac4ad561.svg");
const __default__ = {
  name: "ButtonSocialMediaComponent"
};
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  ...__default__,
  __ssrInlineRender: true,
  props: {
    size: null,
    facebook: { type: Boolean },
    twiter: { type: Boolean },
    instagram: { type: Boolean },
    linkein: { type: Boolean },
    telegram: { type: Boolean },
    discord: { type: Boolean }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (__props.facebook) {
        _push(`<a href="#!" type="button"><img class="${ssrRenderClass(__props.size)}"${ssrRenderAttr("src", _imports_1)} alt="Facebook"></a>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.twiter) {
        _push(`<a href="#!" type="button"><img class="${ssrRenderClass(__props.size)}"${ssrRenderAttr("src", _imports_2)} alt="Twiter"></a>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.instagram) {
        _push(`<a href="#!" type="button"><img class="${ssrRenderClass(__props.size)}"${ssrRenderAttr("src", _imports_3$1)} alt="Instagram"></a>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.linkein) {
        _push(`<a class="${ssrRenderClass(__props.size)}" href="#!" type="button"><img${ssrRenderAttr("src", _imports_3)} alt="Linkein"></a>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.telegram) {
        _push(`<a class="${ssrRenderClass(__props.size)}" href="#!" type="button"><img${ssrRenderAttr("src", _imports_4$1)} alt="Telegram"></a>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.discord) {
        _push(`<a class="${ssrRenderClass(__props.size)}" href="#!" type="button"><img${ssrRenderAttr("src", _imports_5)} alt="Discord"></a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Buttons/ButtonSocialMedia.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<button${ssrRenderAttrs(mergeProps({ class: "rounded-[20px] mt-16 py-14 px-34 border dark:text-white" }, _attrs))}> Get started </button>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Button/LoginButton.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const LoginButton = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + globalThis.__buildAssetsURL("menu-mobile.7ae199fd.svg");
const _imports_4 = "" + globalThis.__buildAssetsURL("logout-mobile.641f3982.svg");
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Device",
  __ssrInlineRender: true,
  setup(__props) {
    const showMenu = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="px-4 sm:px-6 lg:px-8 laptop:hidden max-[359px]:px-0"><div class="flex space-x-4 justify-between items-start w-full"><div class="flex justify-between w-full"><span class="flex relative z-[1]"><img class="pt-24 sm:mr-[22px]"${ssrRenderAttr("src", _imports_0)} alt="menu-mobile"></span><span class="flex items-center pt-32 max-[359px]:pt-24 max-[359px]:justify-center max-[359px]:pl-10 max-[359px]:pr-10 sm:w-full justify-center">`);
      _push(ssrRenderComponent(_sfc_main$6, {
        width: "96",
        height: "32",
        class: "pr-14"
      }, null, _parent));
      _push(`<img class="w-[24px] h-[24px] max-[359px]:pl-[3px] max-[359px]:ml-[3px]"${ssrRenderAttr("src", _imports_1)} alt="Facebook"><img class="w-[24px] h-[24px] ml-5 max-[359px]:ml-[3px] max-[359px]:pl-[3px]"${ssrRenderAttr("src", _imports_2)} alt="Twiter"><img class="w-[24px] h-[24px] ml-5 max-[359px]:ml-[3px] max-[359px]:pl-[3px]"${ssrRenderAttr("src", _imports_3$1)} alt="Instagram"></span><span class="flex"><img class="pt-24 mr-0"${ssrRenderAttr("src", _imports_4)} alt="Log-out-mobile"></span></div></div></div><div id="mobile-menu" class="${ssrRenderClass([
        unref(showMenu) ? "h-full fixed top-0 right-0 z-41 overflow-hidden transition-all duration-700 pt-2 sm:w-5/12 lg:w-0 w-4/6" : "h-full w-0 fixed z-41 top-0 right-0 overflow-hidden transition-all duration-700 pt-2",
        "dark:bg-[#53575996] bg-[#EEEFF3] backdrop-blur-[98px] z-[41]"
      ])}"><div class="h-full flex flex-col justify-between px-34 py-30"><span class="flex items-center max-[359px]:pt-24 max-[359px]:justify-start max-[359px]:pl-10 max-[359px]:pr-10 sm:w-full justify-start"><img class="w-[24px] h-[24px] max-[359px]:pl-[3px] max-[359px]:ml-[3px]"${ssrRenderAttr("src", _imports_1)} alt="Facebook"><img class="w-[24px] h-[24px] ml-5 max-[359px]:ml-[3px] max-[359px]:pl-[3px]"${ssrRenderAttr("src", _imports_2)} alt="Twiter"><img class="w-[24px] h-[24px] ml-5 max-[359px]:ml-[3px] max-[359px]:pl-[3px]"${ssrRenderAttr("src", _imports_3$1)} alt="Instagram"></span><span class="font-medium text-[16px] leading-[50px] font-[&#39;Poppins&#39;] not-italic grid"><a href="#about">What it is?</a><a href="#instructions">Instructions</a><a href="#portfolio">Portfolio</a><a href="#testimonials">Testimonials</a><a href="#faq">FAQ</a><a href="#faq">Blog</a></span><span class="flex flex-col"><div class="w-full flex justify-center"><div class="bg-[#4F5356] rounded mt-24 mr-15 flex items-center p-[2px] w-max"><span class="flex items-center p-[2px]"><button id="theme-toggle" type="button" class="bg-[#4F5356] rounded flex items-center p-[2px]"><svg id="theme-toggle-light-icon" class="rounded w-7 h-7 p-[4px] text-white bg-gradient-to-br from-purple via-bluelight to-yellow dark:from-[#4F5356]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.0001 5.00002C10.4601 5.00002 10.8334 4.62752 10.8334 4.16669V2.50002C10.8334 2.03919 10.4601 1.66669 10.0001 1.66669C9.54008 1.66669 9.16675 2.03919 9.16675 2.50002V4.16669C9.16675 4.62752 9.54008 5.00002 10.0001 5.00002ZM10.0001 11.6667C9.08092 11.6667 8.33342 10.9192 8.33342 10C8.33342 9.08085 9.08092 8.33335 10.0001 8.33335C10.9192 8.33335 11.6667 9.08085 11.6667 10C11.6667 10.9192 10.9192 11.6667 10.0001 11.6667ZM10.0001 6.66669C8.16175 6.66669 6.66675 8.16169 6.66675 10C6.66675 11.8384 8.16175 13.3334 10.0001 13.3334C11.8384 13.3334 13.3334 11.8384 13.3334 10C13.3334 8.16169 11.8384 6.66669 10.0001 6.66669ZM15.8334 9.16669H17.5001C17.9601 9.16669 18.3334 9.53919 18.3334 10C18.3334 10.4609 17.9601 10.8334 17.5001 10.8334H15.8334C15.3734 10.8334 15.0001 10.4609 15.0001 10C15.0001 9.53919 15.3734 9.16669 15.8334 9.16669ZM5.00008 10C5.00008 9.53919 4.62675 9.16669 4.16675 9.16669H2.50008C2.04008 9.16669 1.66675 9.53919 1.66675 10C1.66675 10.4609 2.04008 10.8334 2.50008 10.8334H4.16675C4.62675 10.8334 5.00008 10.4609 5.00008 10ZM4.00566 4.2111C4.32566 3.8811 4.85316 3.8711 5.184 4.19027L6.38316 5.3486C6.714 5.66777 6.72316 6.1961 6.40316 6.52694C6.23983 6.6961 6.02233 6.7811 5.804 6.7811C5.59566 6.7811 5.38733 6.70444 5.22483 6.54777L4.02566 5.38944C3.69483 5.07027 3.68566 4.54194 4.00566 4.2111ZM14.1961 6.78144C14.4044 6.78144 14.6127 6.70394 14.7752 6.5481L15.9744 5.38977C16.3053 5.06977 16.3144 4.54144 15.9944 4.21144C15.6752 3.88144 15.1486 3.87144 14.8161 4.1906L13.6169 5.3481C13.2861 5.6681 13.2769 6.19644 13.5969 6.52644C13.7602 6.6956 13.9777 6.78144 14.1961 6.78144ZM9.16675 15.8334C9.16675 15.3725 9.54008 15 10.0001 15C10.4601 15 10.8334 15.3725 10.8334 15.8334V17.5C10.8334 17.9609 10.4601 18.3334 10.0001 18.3334C9.54008 18.3334 9.16675 17.9609 9.16675 17.5V15.8334ZM14.7751 13.4522C14.4442 13.133 13.9167 13.143 13.5967 13.473C13.2767 13.8039 13.2859 14.3322 13.6167 14.6514L14.8159 15.8097C14.9784 15.9664 15.1867 16.043 15.3951 16.043C15.6134 16.043 15.8309 15.958 15.9942 15.7889C16.3142 15.458 16.3051 14.9297 15.9742 14.6105L14.7751 13.4522ZM4.02591 14.6105L5.22508 13.4522C5.55675 13.133 6.08425 13.143 6.40341 13.473C6.72341 13.8039 6.71425 14.3322 6.38341 14.6514L5.18425 15.8097C5.02175 15.9664 4.81342 16.043 4.60508 16.043C4.38675 16.043 4.16925 15.958 4.00591 15.7889C3.68591 15.458 3.69508 14.9297 4.02591 14.6105Z"></path></svg><svg id="theme-toggle-dark-icon" class="rounded w-7 h-7 p-[4px] text-gray dark:text-white bg-[#4F5356] dark:bg-gradient-to-br from-purple via-bluelight to-yellow" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.65634 4.80639C6.28969 5.06598 5.95312 5.36662 5.64807 5.70687C3.55894 8.03211 3.62714 11.7528 5.79986 14.0003C6.94818 15.189 8.49101 15.8519 10.1438 15.8658C10.1622 15.8665 10.1812 15.8665 10.2003 15.8665C11.8319 15.8665 13.3637 15.2337 14.5193 14.0802C14.7599 13.8405 14.9784 13.5831 15.1742 13.3088C12.8673 13.5963 10.5024 12.8234 8.82246 11.1471C7.14324 9.47082 6.36596 7.11111 6.65634 4.80639ZM10.2002 17.3331C10.1768 17.3331 10.154 17.3331 10.1306 17.3324C8.08176 17.3148 6.16862 16.4935 4.74532 15.0203C2.04903 12.2302 1.9647 7.61266 4.55613 4.72719C5.36348 3.82745 6.34901 3.15063 7.48487 2.71579C7.75252 2.61166 8.05683 2.67619 8.26142 2.87858C8.466 3.08023 8.5342 3.38308 8.43521 3.65293C7.61539 5.89311 8.17416 8.42734 9.85851 10.1088C11.5436 11.7902 14.0844 12.3482 16.3319 11.5299C16.6018 11.4301 16.9054 11.5005 17.1063 11.7044C17.3072 11.9104 17.371 12.214 17.2676 12.4817C16.8834 13.4811 16.307 14.3684 15.5547 15.1186C14.1226 16.5485 12.2234 17.3331 10.2002 17.3331Z"></path></svg></button></span></div></div>`);
      _push(ssrRenderComponent(LoginButton, null, null, _parent));
      _push(`</span></div></div><!--]-->`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/Device.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-black" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$6, null, null, _parent));
      _push(`<div class="px-0 sm:px-0 lg:px-0 xl:px-4 hidden laptop:block"><div class="flex space-x-4 justify-between items-start w-full"><div class="flex-shrink-0 flex">`);
      _push(ssrRenderComponent(_sfc_main$6, {
        width: "96",
        height: "32",
        class: "pt-24 mr-[80px] lg:mr-0"
      }, null, _parent));
      _push(`<span class="flex items-center pt-32">`);
      _push(ssrRenderComponent(_sfc_main$5, {
        size: "w-5 h-5 ml-5",
        facebook: true,
        twiter: true,
        instagram: true
      }, null, _parent));
      _push(`</span></div><span class="pt-32 normal text-sm font-[&#39;Poppins&#39;] not-italic"><a href="#about" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium" aria-current="page">What it is?</a><a href="#instructions" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium">Instructions</a><a href="#portfolio" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium">Portfolio</a><a href="#testimonials" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium">Testimonials</a><a href="#" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium">FAQ</a><a href="#" class="text-gray-300 dark:text-white hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow dark:hover:text-white/0 bg-clip-text bg-gradient-to-r from-purple via-bluelight to-yellow px-3 py-2 rounded-md text-sm font-medium">Blog</a></span><span class="flex items-start"><span class="dark:bg-[#242528] bg-[#EDEEF3] rounded mt-24 mr-15 flex items-center p-[2px]"><span class="flex items-center p-[2px] z-[10]"><button id="theme-toggle" type="button" class="dark:bg-graySelect bg-whiteSelect rounded flex items-center p-[2px]"><svg id="theme-toggle-light-icon" class="rounded w-7 h-7 p-[4px] text-[#EDEEF3] gradiant-icon" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.0001 5.00002C10.4601 5.00002 10.8334 4.62752 10.8334 4.16669V2.50002C10.8334 2.03919 10.4601 1.66669 10.0001 1.66669C9.54008 1.66669 9.16675 2.03919 9.16675 2.50002V4.16669C9.16675 4.62752 9.54008 5.00002 10.0001 5.00002ZM10.0001 11.6667C9.08092 11.6667 8.33342 10.9192 8.33342 10C8.33342 9.08085 9.08092 8.33335 10.0001 8.33335C10.9192 8.33335 11.6667 9.08085 11.6667 10C11.6667 10.9192 10.9192 11.6667 10.0001 11.6667ZM10.0001 6.66669C8.16175 6.66669 6.66675 8.16169 6.66675 10C6.66675 11.8384 8.16175 13.3334 10.0001 13.3334C11.8384 13.3334 13.3334 11.8384 13.3334 10C13.3334 8.16169 11.8384 6.66669 10.0001 6.66669ZM15.8334 9.16669H17.5001C17.9601 9.16669 18.3334 9.53919 18.3334 10C18.3334 10.4609 17.9601 10.8334 17.5001 10.8334H15.8334C15.3734 10.8334 15.0001 10.4609 15.0001 10C15.0001 9.53919 15.3734 9.16669 15.8334 9.16669ZM5.00008 10C5.00008 9.53919 4.62675 9.16669 4.16675 9.16669H2.50008C2.04008 9.16669 1.66675 9.53919 1.66675 10C1.66675 10.4609 2.04008 10.8334 2.50008 10.8334H4.16675C4.62675 10.8334 5.00008 10.4609 5.00008 10ZM4.00566 4.2111C4.32566 3.8811 4.85316 3.8711 5.184 4.19027L6.38316 5.3486C6.714 5.66777 6.72316 6.1961 6.40316 6.52694C6.23983 6.6961 6.02233 6.7811 5.804 6.7811C5.59566 6.7811 5.38733 6.70444 5.22483 6.54777L4.02566 5.38944C3.69483 5.07027 3.68566 4.54194 4.00566 4.2111ZM14.1961 6.78144C14.4044 6.78144 14.6127 6.70394 14.7752 6.5481L15.9744 5.38977C16.3053 5.06977 16.3144 4.54144 15.9944 4.21144C15.6752 3.88144 15.1486 3.87144 14.8161 4.1906L13.6169 5.3481C13.2861 5.6681 13.2769 6.19644 13.5969 6.52644C13.7602 6.6956 13.9777 6.78144 14.1961 6.78144ZM9.16675 15.8334C9.16675 15.3725 9.54008 15 10.0001 15C10.4601 15 10.8334 15.3725 10.8334 15.8334V17.5C10.8334 17.9609 10.4601 18.3334 10.0001 18.3334C9.54008 18.3334 9.16675 17.9609 9.16675 17.5V15.8334ZM14.7751 13.4522C14.4442 13.133 13.9167 13.143 13.5967 13.473C13.2767 13.8039 13.2859 14.3322 13.6167 14.6514L14.8159 15.8097C14.9784 15.9664 15.1867 16.043 15.3951 16.043C15.6134 16.043 15.8309 15.958 15.9942 15.7889C16.3142 15.458 16.3051 14.9297 15.9742 14.6105L14.7751 13.4522ZM4.02591 14.6105L5.22508 13.4522C5.55675 13.133 6.08425 13.143 6.40341 13.473C6.72341 13.8039 6.71425 14.3322 6.38341 14.6514L5.18425 15.8097C5.02175 15.9664 4.81342 16.043 4.60508 16.043C4.38675 16.043 4.16925 15.958 4.00591 15.7889C3.68591 15.458 3.69508 14.9297 4.02591 14.6105Z"></path></svg><svg id="theme-toggle-dark-icon" class="rounded w-7 h-7 p-[4px] text-gray dark:text-white bg-[#EDEEF3] dark:bg-gradient-to-br from-purple via-bluelight to-yellow" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.65634 4.80639C6.28969 5.06598 5.95312 5.36662 5.64807 5.70687C3.55894 8.03211 3.62714 11.7528 5.79986 14.0003C6.94818 15.189 8.49101 15.8519 10.1438 15.8658C10.1622 15.8665 10.1812 15.8665 10.2003 15.8665C11.8319 15.8665 13.3637 15.2337 14.5193 14.0802C14.7599 13.8405 14.9784 13.5831 15.1742 13.3088C12.8673 13.5963 10.5024 12.8234 8.82246 11.1471C7.14324 9.47082 6.36596 7.11111 6.65634 4.80639ZM10.2002 17.3331C10.1768 17.3331 10.154 17.3331 10.1306 17.3324C8.08176 17.3148 6.16862 16.4935 4.74532 15.0203C2.04903 12.2302 1.9647 7.61266 4.55613 4.72719C5.36348 3.82745 6.34901 3.15063 7.48487 2.71579C7.75252 2.61166 8.05683 2.67619 8.26142 2.87858C8.466 3.08023 8.5342 3.38308 8.43521 3.65293C7.61539 5.89311 8.17416 8.42734 9.85851 10.1088C11.5436 11.7902 14.0844 12.3482 16.3319 11.5299C16.6018 11.4301 16.9054 11.5005 17.1063 11.7044C17.3072 11.9104 17.371 12.214 17.2676 12.4817C16.8834 13.4811 16.307 14.3684 15.5547 15.1186C14.1226 16.5485 12.2234 17.3331 10.2002 17.3331Z"></path></svg></button></span></span>`);
      _push(ssrRenderComponent(LoginButton, { class: "lg:ml-5 ml-[60px] xl:ml-[60px]" }, null, _parent));
      _push(`</span></div></div>`);
      _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      _push(`</nav>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/Header.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "text-center text-gray-300 dark:text-white dark:bg-black pt-24 border-t" }, _attrs))} data-v-2faa8a35><div class="flex justify-between dark:bg-black" data-v-2faa8a35><a href="#!" type="button" data-v-2faa8a35>`);
      _push(ssrRenderComponent(_sfc_main$6, {
        width: "96",
        height: "32"
      }, null, _parent));
      _push(`</a><span class="md:flex hidden md:block" data-v-2faa8a35><a class="text-whitehite pr-4" data-v-2faa8a35><p class="pr-4" data-v-2faa8a35>Privacity policy</p></a><a class="text-whitehite pl-4" data-v-2faa8a35><p data-v-2faa8a35>Term of use</p></a></span><div class="flex justify-between items-center" data-v-2faa8a35>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        size: "max-[350px]:ml-[10px] min-[351px]:ml-[20px] ml-[20px] min-h-[20px] min-w-[20px]",
        facebook: true,
        linkein: true,
        telegram: true,
        discord: true
      }, null, _parent));
      _push(`</div></div><div class="text-center flex justify-between block md:hidden pt-twenty pb-6 md:pt-16.1 md:pb-10" data-v-2faa8a35><span class="flex" data-v-2faa8a35><a class="text-gray-300 hover:bg-gray-700 hover:text-white pr-2 md:pr-4 underline" data-v-2faa8a35><p data-v-2faa8a35>Privacity policy</p></a><a class="text-gray-300 hover:bg-gray-700 hover:text-white pl-2 md:pl-4 underline" data-v-2faa8a35><p data-v-2faa8a35>Term of use</p></a></span><span class="text-gray-300 hover:bg-gray-700 hover:text-white flex" data-v-2faa8a35><span class="text-gray pr-2" data-v-2faa8a35> made</span> by roobinium.io</span></div><div class="text-gray-300 hover:bg-gray-700 hover:text-white text-center flex justify-between md:pt-16.1 pb-10" data-v-2faa8a35><span data-v-2faa8a35><p data-v-2faa8a35>All right reserved \xA9 2022 Socal trade</p></span><span class="text-gray-300 hover:bg-gray-700 hover:text-white md:flex hidden md:block" data-v-2faa8a35><span class="text-gray pr-2" data-v-2faa8a35> made </span> by roobinium.io</span></div></footer>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-2faa8a35"]]);
const _sfc_main = {
  __name: "Default",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = _sfc_main$2;
      const _component_Footer = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white text-black dark:text-white dark:bg-black min-h-screen px-4 xl:px-[80px]" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<main class="mb-auto">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/Default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Default.979ea4ed.mjs.map
