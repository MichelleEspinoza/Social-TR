import { useSSRContext, defineComponent, ref, computed, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderStyle, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _imports_0$3 = "" + globalThis.__buildAssetsURL("mobile-cover.9cdd41f9.svg");
const _sfc_main$c = {};
function _sfc_ssrRender$8(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "h-[120px] w-full bg-darkOpacity dark:bg-whiteOpacity backdrop-blur-[13px] rounded-[24px] box-border flex justify-between mt-[7vh] items-center max-laptop:px-[24px] max-laptop:py-[16px] py-8 px-[40px]" }, _attrs))}><div class="font-[500] text-[16px] leading-7 text-dark dark:text-white max-laptop:hidden"><p>Just subscriibe to expert traders and watch the</p><p>app copy their market moves</p></div><div class="flex max-laptop:justify-between max-laptop:w-full"><span><p class="max-[305px]:text-[16px] min-[306px]:text-[20px] font-[700] leading-7 gradiant-icon title-card-cover"> 128K+ </p><p class="max-[305px]:text-[12px] min-[306px]:text-[14px] block font-[400] leading-6"> Lifetime Volume </p></span><span class="max-laptop:pl-0 pl-[60px]"><p class="max-[305px]:text-[16px] min-[306px]:text-[20px] font-[700] leading-7 gradiant-icon title-card-cover"> 40K+ </p><p class="max-[305px]:text-[12px] min-[306px]:text-[14px] block font-[400] leading-6"> Lifetime Volume </p></span><span class="max-laptop:px-0 px-[60px]"><p class="max-[305px]:text-[16px] min-[306px]:text-[20px] font-[700] leading-7 gradiant-icon title-card-cover"> 600K+ </p><p class="max-[305px]:text-[12px] min-[306px]:text-[14px] block font-[400] leading-6"> USDT Managed </p></span></div></div>`);
}
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cover/CardInformation.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const CardInformation = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["ssrRender", _sfc_ssrRender$8]]);
const _sfc_main$b = {};
function _sfc_ssrRender$7(_ctx, _push, _parent, _attrs) {
  _push(`<button${ssrRenderAttrs(mergeProps({ class: "w-[180px] h-[52px] min-[1920px]:w-[250px] min-[1920px]:h-[62px] bg-dark dark:bg-white text-white dark:text-dark font-['Poppins'] not-italic font-[500] text-[14px] leading-6 rounded-2xl button-shadow" }, _attrs))}> Get Start </button>`);
}
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Button/GetStartButton.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const GetStartButton = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["ssrRender", _sfc_ssrRender$7]]);
const _sfc_main$a = {};
function _sfc_ssrRender$6(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative z-[1] text-dark dark:text-white dark:drop-shadow-[0_2px_30px_rgba(0,0,0,1)] laptop:mt-[8.5vw] laptop:font-[800] laptop:text-[7.5vw] laptop:leading-[7vw] text-center uppercase" }, _attrs))}><p>Let the</p><p>Professionals</p><p>Earn for you</p></div>`);
}
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cover/Title.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const TitleCover = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["ssrRender", _sfc_ssrRender$6]]);
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "Device",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col justify-between pb-5 laptop:hidden" }, _attrs))}><div><div class="absolute w-[120px] h-[637px] l-[60px] t-[0] bg-greenShadow blur-[178px]"></div><img class="max-[359px]:pl-[3px] max-[359px]:ml-[3px] max-sm:pl-[0px] max-sm:pr-[0px] max-md:pl-[30px] max-md:pr-[30px] max-laptop:pl-[70px] max-laptop:pr-[70px] w-full h-full relative z-[1]"${ssrRenderAttr("src", _imports_0$3)} alt="Cover"><span class="max-sm:top-[89vw] max-md:top-[77vw] max-md:text-[9vw] max-md:leading-[10vw] max-laptop:top-[69vw] max-laptop:text-[9vw] max-laptop:leading-[10vw] absolute z-[10] font-[800] text-center text-dark dark:text-white right-[0px] left-[0px]"><div class="hidden dark:block max-sm:top-[0vw] max-md:blur-[40px] min-[641px]:top-[10vw] min-[641px]:blur-[90px] h-[104px] min-[641px]:h-[320px] dark:bg-darkShadow w-full absolute z-[1]"></div>`);
      _push(ssrRenderComponent(TitleCover, null, null, _parent));
      _push(`</span></div><span class="max-sm:text-[3.7vw] max-sm:leading-[1.7] max-md:text-[3.0vw] max-md:leading-[1.7] max-sm:pt-[24px] max-md:pt-[24px] max-laptop:pt-[30px] max-laptop:text-[2.5vw] max-laptop:leading-[1.7] font-[500] text-center"><p class="mt-[1px] relative z-[10] ml-[16px] mr-[16px]"> Just subscribe to expert traders and </p><p class="mt-[1px] relative z-[10] ml-[16px] mr-[16px]"> watch the app copy their market moves </p></span><div class="w-full pt-8 mb-10 text-center relative z-[10]">`);
      _push(ssrRenderComponent(GetStartButton, null, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(CardInformation, null, null, _parent));
      _push(`<div class="absolute w-[120px] h-[664px] right-[0px] top-[0px] bg-blueShadow blur-[178px]"></div></div>`);
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cover/Device.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "Cover",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="xl:px-[5vh] max-laptop:hidden block font-[&#39;Poppins&#39;] not-italic"><div class="lines-cover top-0 left-[50px]"></div><div class="absolute left-[-60px] bottom-[0px] w-[10%] h-[80%] bg-greenShadow blur-[400px]"></div><div class="bg-[url(&#39;../../assets/svg/desktop-cover.svg&#39;)] bg-no-repeat bg-cover bg-[left_calc(25%)_top_calc(15%)]"><div class="h-full w-full flex justify-center items-start"><span class="flex flex-col"><div class="lines-cover left-[36.65%] top-0"></div>`);
      _push(ssrRenderComponent(TitleCover, null, null, _parent));
      _push(`<div class="lines-cover left-[63%] top-0"></div><div class="mt-[7vh] text-center relative top-[-5vh]">`);
      _push(ssrRenderComponent(GetStartButton, null, null, _parent));
      _push(`</div></span></div>`);
      _push(ssrRenderComponent(CardInformation, { class: "mb-[10vw]" }, null, _parent));
      _push(`</div><div class="lines-cover top-0 right-[50px]"></div><div class="absolute w-[10%] h-[90%] right-[0px] top-[0px] bg-blueShadow blur-[332px]"></div></div>`);
      _push(ssrRenderComponent(_sfc_main$9, { class: "font-['Poppins'] not-italic" }, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/Cover.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  name: "AboutComponent"
};
const _imports_0$2 = "" + globalThis.__buildAssetsURL("video.542bfd5d.png");
function _sfc_ssrRender$5(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    id: "about",
    class: ""
  }, _attrs))}><div id="seccion-2"><br><div class="px-0 hidden laptop:block"><div class="grid grid-cols-8 gap-4 pl-[80px] pr-[80px]"><div class="... relative"><p class="absolute right-[-5vw] rotate-180 vertical-lr upper-title text-border-white dark:text-border-dark text-white dark:text-black laptop:text-[14vw] min-[1440px]:text-[12vw]"> ABOUT </p></div><div class="relative col-span-7 ..."><div class="grid grid-cols-[40%_60%] gap-0"><div class="col-span-1"><h1 class="text-7xl title uppercase text-left ml-[2.5vw] mr-4 leading-[68px]"> Social<br>Trader </h1></div><div class="col-span-1 xl:mr-[183px] lg:mr-[100px]"><p class="subtitle relative"> Not Just a copy, but a community </p><p class="text relative"> Sales promotion unnaturally justifies the tactical consumer market. Strategic planning develops the image. Positioning in the market distorts the empirical image, realizing the social responsibility of the business. </p></div><div class="absolute top-[10vw] xl:top-[7vw] right-[12vw] xl:right-[17vw] background-gradient-title w-[53vw] h-[6rem] blur-[121px] rounded-full max-[480px]:w-full"></div></div><div class="row-span-2 col-span-2 ml-[2.5vw] mx-4 mt-10 xl:mr-[200px] lg:mr-[100px]"><img${ssrRenderAttr("src", _imports_0$2)} width="100%" alt=""></div></div></div></div><div class="sm:px-0 laptop:px-2 laptop:hidden max-[359px]:px-0"><div class="relative flex flex-col w-full space-x-1 items-start"><div><h1 class="relative top-[14vw] md:top-[13.2vw] min-[830px]:top-[12.6vw] min-[900px]:top-[12vw] upper-title about-mobile-text text-border-white dark:text-border-dark text-white dark:text-black"> ABOUT </h1><h1 class="relative title uppercase ml-1 text-left"> Social Trader </h1><div class="absolute right-0 top-[45vw] w-[88%] h-[13%] rounded-l-full-oval background-gradient-title blur-[121px] max-[480px]:h-[25%] max-[280px]:h-[50%] opacity-75"></div></div><div class="mt-[4vw]"><p class="subtitle relative mr-4"> Not Just a copy, but a community </p><p class="text relative mb-[7vw] sm:mr-[2rem] min-[280px]:mr-2"> Sales promotion unnaturally justifies the tactical consume market. Strategic planning develops the image. Positioning in the market distorts the empirical image, realizing the social responsibility of the business. </p></div><div><img${ssrRenderAttr("src", _imports_0$2)} width="900" alt=""></div></div></div></div></div>`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/About.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const About = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$5]]);
const _sfc_main$6 = defineComponent({
  name: "TableComponent",
  props: {
    tableHeader: {
      type: Array,
      required: true
    },
    tableData: { type: Array, required: true },
    emptyTableText: { type: String, default: "No data found" },
    loading: { type: Boolean, default: false },
    currentPage: { type: Number, default: 1 },
    enableItemsPerPageDropdown: { type: Boolean, default: true },
    total: { type: Number, default: 0 },
    rowsPerPage: { type: Number, default: 10 },
    order: { type: String, default: "asc" },
    sortLabel: { type: String, default: "" }
  },
  setup(props) {
    const data = ref(props.tableData);
    const getItems = computed(() => {
      return data.value;
    });
    return {
      data,
      getItems
    };
  }
});
function _sfc_ssrRender$4(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  var _a;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col" }, _attrs))}><div class="overflow-x-auto"><div class="py-2 inline-block min-w-full sm:px-6"><div class="overflow-x-auto table-radius"><table class="min-w-full text-left text-sm white-mode backdrop-blur-[13px] dark:bg-whiteOpacity"><thead class="text-dark dark:text-white max-[298px]:text-[18px] min-[306px]:text-[14px] text-sm opacity-[.6] leading-[24px] font-[400] backdrop-blur-[13px] border-b-[1px] border-white"><tr><!--[-->`);
  ssrRenderList(_ctx.tableHeader, (cell, i) => {
    _push(`<th class="${ssrRenderClass([[
      cell.name && "min-w-125px",
      _ctx.tableHeader.length - 1 === i && "text-end"
    ], "px-22 py-4 font-medium text-dark dark:text-white"])}" tabindex="0" rowspan="1" colspan="1" style="${ssrRenderStyle({ "cursor": "pointer" })}">${ssrInterpolate(cell.name)}</th>`);
  });
  _push(`<!--]--></tr></thead><tbody class="text-dark dark:text-white max-[298px]:text-[20px] min-[306px]:text-[16px] text-sm leading-[24px] font-[500]">`);
  if ((_a = _ctx.getItems) == null ? void 0 : _a.length) {
    _push(`<!--[-->`);
    ssrRenderList(_ctx.getItems, (item, i) => {
      _push(`<tr class="hover:bg-whiteOpacity"><!--[-->`);
      ssrRenderList(_ctx.tableHeader, (cell, i2) => {
        _push(`<td class="${ssrRenderClass([{ "text-end": _ctx.tableHeader.length - 1 === i2 }, "px-22"])}">`);
        ssrRenderSlot(_ctx.$slots, `cell-${cell.key}`, { row: item }, () => {
          _push(`${ssrInterpolate(item[_ctx.prop])}`);
        }, _push, _parent);
        _push(`</td>`);
      });
      _push(`<!--]--></tr>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<tr class="odd"><td colspan="7" class="dataTables_empty">${ssrInterpolate(_ctx.emptyTableText)}</td></tr>`);
  }
  _push(`</tbody></table></div></div></div></div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tables/DataTable.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const DataTable = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$4]]);
const __default__ = {
  name: "IntroductionComponent"
};
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  ...__default__,
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const datas = [
      {
        id: 1,
        nickName: {
          icon: "https://i0.wp.com/artplugged.co.uk/wp-content/uploads/2022/09/The-Digital-Asset-Policy-Alliance-barbora-dostalova-art-plugged_.jpg?fit=1500%2C844&ssl=1",
          name: "Jessse Lauriston Livermore"
        },
        roi: "63.55",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 2,
        nickName: {
          icon: "https://images6.alphacoders.com/101/thumbbig-1012089.webp",
          name: "CEO - JeffBezos"
        },
        roi: "34.64",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 3,
        nickName: {
          icon: "https://images.unsplash.com/photo-1569081156361-c98e05e7f1e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=435&q=80",
          name: "Adam Shwimmer"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 4,
        nickName: {
          icon: "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTGE7juZY4NJIVM3oXdubCElreX3XPFnsUWRo6x9yfd9lQZjWi0",
          name: "Anna Block"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 5,
        nickName: {
          icon: "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSKeECGIn7DTkInrCUHrogf9H6jdm78-c4LXptzoul34gQvaSHI",
          name: "Angela Bariotti"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 6,
        nickName: {
          icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTD9p4mz3Kssa8fBQRdEyrHu9xIVHlhS0IMESCoI3yBgKybwtIe",
          name: "KIMBIT"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 7,
        nickName: {
          icon: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQEYU5vazWsAZn2jqT6IH3yue_T6uZdq8an_m7MpDDi-L7-zxH_",
          name: "Positive"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 8,
        nickName: {
          icon: "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSf_ODE65A3YdQ2aPHQXCltnvk-RHZQKcFcEvcVS7lraTPsmItk",
          name: "Bugs Bunny"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 9,
        nickName: {
          icon: "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRxwGb2xlQBmuLHjlEa0DiDz0biCAJu192jg2wB8s7LbJ7uwbBm",
          name: "Pablo Picaso"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      },
      {
        id: 10,
        nickName: {
          icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ94f6LsA8uAV6xhAYs05Yl9ymwGhfmcl0a6yHJ8QYPzCEVdPMv",
          name: "MIAMITRADING"
        },
        roi: "25.96",
        masterPL: "785.89",
        followers: "320/1000",
        tradeVolume: "52,785.26",
        winRate: "100%"
      }
    ];
    const tableHeader = ref([
      {
        name: "#",
        key: "num",
        sortable: true
      },
      {
        name: "Nickname",
        key: "nickName",
        sortable: true
      },
      {
        name: "ROI",
        key: "roi",
        sortable: true
      },
      {
        name: "Master\u2019s P&L",
        key: "masterPL",
        sortable: true
      },
      {
        name: "Followers",
        key: "followers",
        sortable: true
      },
      {
        name: "Trade Volume",
        key: "tradeVolume",
        sortable: true
      },
      {
        name: "Win rate",
        key: "winRate",
        sortable: true
      },
      {
        key: "actions"
      }
    ]);
    const tableData = ref(datas);
    expose({
      tableData,
      tableHeader
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col ..." }, _attrs))}><div id="title-introducction"><h1 class="text-left relative top-[9vw] md:top-[8.2vw] min-[830px]:top-[7.6vw] min-[900px]:top-[7vw] upper-title introduction-mobile-text text-border-white dark:text-border-dark text-white dark:text-black"> INTRODUCTION </h1><h1 class="relative title uppercase ml-1 text-left">How does it work?</h1></div><div id="cards">card</div><div id="table"><div class="flex items-center flex-row max-[480px]:flex-col max-[480px]:items-start"><div class="basis-3/4"><h1 class="relative title uppercase ml-1 text-left"> Top traders\xA0\u{1F525} </h1></div><div class="basis-1/4 text-right"><div class="bg-[#86DCA5] w-[16rem] h-[16rem] blur-[252px] rounded-full absolute max-[480px]:w-full"></div><button class="w-[180px] h-[52px] min-[1920px]:w-[250px] min-[1920px]:h-[62px] max-[480px]:w-[175px] max-[480px]:h-[45px] bg-dark dark:bg-white text-white dark:text-dark font-[&#39;Poppins&#39;] not-italic font-[500] text-[14px] leading-6 rounded-2xl shadow-md hover:shadow-white focus:shadow-none"> Join as a trader </button></div></div>`);
      _push(ssrRenderComponent(DataTable, {
        "table-data": unref(tableData),
        "table-header": unref(tableHeader)
      }, {
        "cell-num": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(data.id)}`);
          } else {
            return [
              createTextVNode(toDisplayString(data.id), 1)
            ];
          }
        }),
        "cell-nickName": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="flex align-items-center"${_scopeId}><img class="rounded-full h-10 w-10 object-cover"${ssrRenderAttr("src", data.nickName.icon)} alt="unsplash image"${_scopeId}><div class="ml-3 mt-3"${_scopeId}>${ssrInterpolate((_a = data.nickName) == null ? void 0 : _a.name)}</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex align-items-center" }, [
                createVNode("img", {
                  class: "rounded-full h-10 w-10 object-cover",
                  src: data.nickName.icon,
                  alt: "unsplash image"
                }, null, 8, ["src"]),
                createVNode("div", { class: "ml-3 mt-3" }, toDisplayString((_b = data.nickName) == null ? void 0 : _b.name), 1)
              ])
            ];
          }
        }),
        "cell-roi": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="gradiant-text-table-opacity rounded-md px-2"${_scopeId}><span class="gradiant-text-table gradiant-text"${_scopeId}>+\xA0${ssrInterpolate(data.roi)}%</span></span>`);
          } else {
            return [
              createVNode("span", { class: "gradiant-text-table-opacity rounded-md px-2" }, [
                createVNode("span", { class: "gradiant-text-table gradiant-text" }, "+\xA0" + toDisplayString(data.roi) + "%", 1)
              ])
            ];
          }
        }),
        "cell-masterPL": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span${_scopeId}>${ssrInterpolate(data.masterPL)}</span>`);
          } else {
            return [
              createVNode("span", null, toDisplayString(data.masterPL), 1)
            ];
          }
        }),
        "cell-followers": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span${_scopeId}>${ssrInterpolate(data.followers)}</span>`);
          } else {
            return [
              createVNode("span", null, toDisplayString(data.followers), 1)
            ];
          }
        }),
        "cell-tradeVolume": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span${_scopeId}>+\xA0${ssrInterpolate(data.tradeVolume)}</span>`);
          } else {
            return [
              createVNode("span", null, "+\xA0" + toDisplayString(data.tradeVolume), 1)
            ];
          }
        }),
        "cell-winRate": withCtx(({ row: data }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="gradiant-text-table gradiant-text"${_scopeId}>${ssrInterpolate(data.winRate)}</span>`);
          } else {
            return [
              createVNode("span", { class: "gradiant-text-table gradiant-text" }, toDisplayString(data.winRate), 1)
            ];
          }
        }),
        "cell-actions": withCtx(({}, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="flex justify-center"${_scopeId}><div${_scopeId}><button class="shadow-md hover:shadow-white hover:border-white hover:bg-white hover:text-dark active:bg-white focus:shadow-none focus:bg-transparent focus:text-white bg-transparent rounded-[16px] mt-2 mb-2 py-2 px-34 laptop:px-[3.2vw] border"${_scopeId}> copy </button></div></span>`);
          } else {
            return [
              createVNode("span", { class: "flex justify-center" }, [
                createVNode("div", null, [
                  createVNode("button", { class: "shadow-md hover:shadow-white hover:border-white hover:bg-white hover:text-dark active:bg-white focus:shadow-none focus:bg-transparent focus:text-white bg-transparent rounded-[16px] mt-2 mb-2 py-2 px-34 laptop:px-[3.2vw] border" }, " copy ")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex justify-center text-center flex-row"><div class="basis-4/4 text-center"><p class="max-[298px]:text-[18px] min-[306px]:text-[14px] gradiant-text font-[600px] text-sm leading-[24px] gradiant-text-table hover:gradiant-text-hover hover:gradiant-text active:gradiant-text-table active:gradiant-text"> Show more </p></div></div></div></div>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/Introduction.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  name: "PortafolioComponent"
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    id: "portfolio",
    class: "container mx-4 h-screen"
  }, _attrs))}><p>portafolio</p></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/Portfolio.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Portafolio = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$3 = {
  name: "TestimonialComponent"
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    id: "testimonials",
    class: "container mx-4 h-screen"
  }, _attrs))}><p>testimonial</p></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/Testimonial.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Testimonial = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const _imports_0$1 = "" + globalThis.__buildAssetsURL("faq-arrow.35678e0e.svg");
const _sfc_main$2 = {
  name: "DropdownComponent",
  props: {
    summary: {
      type: String,
      required: true
    },
    details: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      isOpen: false
    };
  },
  methods: {
    toggleDropdown() {
      this.isOpen = !this.isOpen;
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="${ssrRenderClass([
    $data.isOpen ? "scale-110 h-auto absolute z-10 shadow-green-500/50 shadow-2xl" : "scale-100 h-16 ",
    "grid grid-cols-6 items-center p-3 backdrop-blur-3xl bg-[#ffffff18] transition-all duration-700 rounded-[24px] border border-white/10 w-[20rem] sm:w-[30rem] max-[350px]:max-w-[250px]"
  ])}"><h5 class="font-bold col-span-5">${ssrInterpolate($props.summary)}</h5><div class="flex items-center h-full justify-end w-full col-span-1"><button class="${ssrRenderClass([$data.isOpen ? "rotate-180" : "rotate-0", "transition-transform duration-200"])}"><img${ssrRenderAttr("src", _imports_0$1)} alt="Arrow down"></button></div>`);
  if ($data.isOpen) {
    _push(`<div class="col-span-6"><p class="text-white/50">${ssrInterpolate($props.details)}</p></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="${ssrRenderClass($data.isOpen ? "block h-16" : "hidden")}"></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Dropdown/Dropdown.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {
  name: "FaqComponent",
  data() {
    return {
      faqDetails: [
        {
          summary: "How does crypto copytrading work?",
          details: "A cryptocurrency is a "
        },
        {
          summary: "How to copy Traders",
          details: "A cryptocurrency is a "
        },
        {
          summary: "Who should I follow/copy?",
          details: "A cryptocurrency is a "
        },
        {
          summary: "How do I start?",
          details: "A cryptocurrency is a "
        },
        {
          summary: "Is it safe?",
          details: "A cryptocurrency is a "
        }
      ]
    };
  }
};
const _imports_0 = "" + globalThis.__buildAssetsURL("home-page-faq.6686ccf3.svg");
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Dropdown = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({
    id: "faq",
    class: "h-screen lg:grid lg:grid-cols-7"
  }, _attrs))}><div class="col-span-4 lg:col-span-3 xl:col-span-4 flex justify-center h-full items-center absolute lg:relative max-[480px]:pl-[40px] max-[480px]:pr-[40px]"><img${ssrRenderAttr("src", _imports_0)} alt="Spiral helix"><div class="bg-green-500 w-[30rem] h-[30rem] blur-[175px] rounded-full absolute max-[480px]:w-full"></div></div><div class="flex justify-center items-center h-full w-full col-span-3 lg:col-span-4 xl:col-span-3 max-[480px]:pl-[40px] max-[480px]:pr-[40px]"><div class="flex flex-col gap-5 row-span-3 mx-auto lg:mx-0"><div class="flex justify-start items-center"><h1 class="text-7xl mb-5 mx-auto lg:mx-0 z-40 title">FAQ</h1></div><!--[-->`);
  ssrRenderList($data.faqDetails, (faq) => {
    _push(ssrRenderComponent(_component_Dropdown, {
      key: faq.summary,
      summary: faq.summary,
      details: faq.details
    }, null, _parent));
  });
  _push(`<!--]--></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HomePage/Faq.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Faq = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_sfc_main$8, null, null, _parent));
      _push(ssrRenderComponent(About, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, null, null, _parent));
      _push(ssrRenderComponent(Portafolio, null, null, _parent));
      _push(ssrRenderComponent(Testimonial, null, null, _parent));
      _push(ssrRenderComponent(Faq, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.fcf85b8d.mjs.map
