const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./error-404-styles.956de7dd.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./error-500-styles.44debd55.mjs').then(interopDefault),
  "pages/login.vue": () => import('./login-styles.640a0a67.mjs').then(interopDefault),
  "components/Footer/Footer.vue": () => import('./Footer-styles.29cc5b90.mjs').then(interopDefault),
  "components/Dropdown/Dropdown.vue": () => import('./Dropdown-styles.288a899e.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
