const login_vue_vue_type_style_index_0_lang = ".bg{background-image:url(" + globalThis.__publicAssetsURL("backgrounds/login-signup.svg") + ");background-repeat:no-repeat;background-size:cover;z-index:0}.rect{background:linear-gradient(180deg,transparent,#000 42.34%);bottom:0;height:200px;left:0;position:absolute;width:766px}";

const loginStyles_640a0a67 = [login_vue_vue_type_style_index_0_lang];

export { loginStyles_640a0a67 as default };
//# sourceMappingURL=login-styles.640a0a67.mjs.map
