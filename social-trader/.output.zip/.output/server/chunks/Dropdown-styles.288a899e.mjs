const Dropdown_vue_vue_type_style_index_0_lang = ".text-enter-active,.text-leave-active{transition:all .3s ease-out}.text-enter-from,.text-leave-to{opacity:0;transform:translateX(20px)}";

const DropdownStyles_288a899e = [Dropdown_vue_vue_type_style_index_0_lang];

export { DropdownStyles_288a899e as default };
//# sourceMappingURL=Dropdown-styles.288a899e.mjs.map
