import{a as t,b as o,m as r,o as n}from"./entry.a45cc675.js";const s={};function a(e,c){return n(),o("div",null,[r(e.$slots,"default")])}const f=t(s,[["render",a]]);export{f as default};
